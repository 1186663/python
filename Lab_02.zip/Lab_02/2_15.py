#ZADANIE 2.15
#Na liście L znajdują się liczby całkowite dodatnie.
# Stworzyć napis będący ciągiem cyfr kolejnych liczb z listy L.

L = [23, 5, 27, 12, 9]
digit_sequence = ''.join(map(str, L))

print("Napis będący ciągiem cyfr kolejnych liczb z listy L:", digit_sequence)
