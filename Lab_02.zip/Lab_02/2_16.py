#ZADANIE 2.16
#W tekście znajdującym się w zmiennej line zamienić ciąg znaków "GvR" na "Guido van Rossum".

line = "Hello GvR!"
line_change = line.replace("GvR", "Guido van Rossum")

print(line_change)
