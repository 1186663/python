#ZADANIE 2.9 (FILE)
#Napisać funkcję wykonującą kopiowanie pliku, która pomija linie rozpoczynające się od znaku
# # (linie z komentarzami).

def copy_file_without_comments(input_file, output_file):
    try:
        with open(input_file, 'r') as source_file, open(output_file, 'w') as target_file:
            for line in source_file:
                if not line.strip().startswith('#'):
                    target_file.write(line)
        print(f"Skopiowano zawartość {input_file} do {output_file}, pomijając komentarze.")
    except FileNotFoundError:
        print("Nie można odnaleźć pliku źródłowego lub docelowego.")
    except Exception as e:
        print(f"Wystąpił błąd: {e}")


if __name__ == '__main__':
    input_f = 'input.txt'
    output_f = 'output.txt'

    copy_file_without_comments(input_f, output_f)
