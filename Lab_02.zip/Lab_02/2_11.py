#ZADANIE 2.11
#Podać sposób wyświetlania napisu word tak, aby jego znaki były rozdzielone znakiem podkreślenia.

word = "Hello"
word_with_underscores = "_".join(word)
print(word_with_underscores)
