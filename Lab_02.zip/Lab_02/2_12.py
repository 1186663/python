#ZADANIE 2.12
#Zbudować napis stworzony z pierwszych znaków wyrazów z wiersza line.
#Zbudować napis stworzony z ostatnich znaków wyrazów z wiersza line.

line = ("Lorem ipsum dolor sit amet, consectetur adipiscing elit. "
        "Proin vulputate sed nisl et ultricies. Nam finibus mauris "
        "at massa malesuada, ultricies sollicitudin.")

words = line.split()
words = [word.strip(",") for word in words]
words = [word.strip(".") for word in words]

first_letters = [word[0] for word in words]
string_with_first_letters = ''.join(first_letters)

last_letters = [word[-1] for word in words]
string_with_last_letters = ''.join(last_letters)

print("Napis z pierwszymi znakami wyrazów:", string_with_first_letters)
print("Napis z ostatnimi znakami wyrazów:", string_with_last_letters)
