#ZADANIE 2.18
#Znaleźć liczbę cyfr zero w dużej liczbie całkowitej. Wskazówka: zamienić liczbę na napis.

number = 1023040506000

number_string = str(number)
zero_count = number_string.count('0')

print(f"Liczba zer w liczbie {number} to: {zero_count}")
