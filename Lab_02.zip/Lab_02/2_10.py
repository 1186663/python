#ZADANIE 2.10
#Mamy dany napis wielowierszowy line. Podać sposób obliczenia liczby wyrazów w napisie.
# Przez wyraz rozumiemy ciąg "czarnych" znaków, oddzielony od innych wyrazów białymi znakami
# (spacja, tabulacja, newline).

line = ("Lorem ipsum dolor sit amet, consectetur "
        "adipiscing elit. Proin vulputate sed nisl et ultricies. "
        "Nam finibus mauris at massa malesuada, ultricies sollicitudin.")

words = line.split()
print(f"Liczba wyrazów w napisie: {len(words)}")


