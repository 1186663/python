#ZADANIE 2.14
#Znaleźć:
# (a) najdłuższy wyraz,
# (b) długość najdłuższego wyrazu w napisie line.

line = ("Lorem ipsum dolor sit amet, consectetur "
            "adipiscing elit. Proin vulputatevos sed nisl et ultricies. "
            "Nam finibus mauris at massa malesuada, ultricies sollicitudin.")

words = line.split()

words = [word.strip(",") for word in words]
words = [word.strip(".") for word in words]
words = [word.strip() for word in words]

# (a) Znajdź najdłuższe wyrazy
longest_words = [word for word in words if len(word) == len(max(words, key=len))]

# (b) Długość najdłuższych wyrazów
length_of_longest_words = len(longest_words[0])

print("(a) Najdłuższe wyrazy:", longest_words)
print("(b) Długość najdłuższych wyrazów:", length_of_longest_words)
