#ZADANIE 2.19
#Na liście L mamy liczby jedno-, dwu- i trzycyfrowe dodatnie.
# Chcemy zbudować napis z trzycyfrowych bloków, gdzie liczby jedno- i dwucyfrowe
# będą miały blok dopełniony zerami, np. 007, 024. Wskazówka: str.zfill().

L = [7, 24, 123, 45, 6, 89, 100]

# Konwertowanie liczby na napisy z dopełnieniem zerami
blocks = [str(number).zfill(3) for number in L]

word = ''.join(blocks)

print("Napis z trzycyfrowych bloków:\n", word)
