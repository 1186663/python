#ZADANIE 2.13
#Znaleźć łączną długość wyrazów w napisie line.
#Wskazówka: można skorzystać z funkcji sum().

line = ("Lorem ipsum dolor sit amet, consectetur adipiscing elit. "
        "Proin vulputate sed nisl et ultricies. Nam finibus mauris "
        "at massa malesuada, ultricies sollicitudin.")

words = line.split()

word_lengths = [len(word) for word in words]
total_length = sum(word_lengths)

print("Total length of words in the string:", total_length)
