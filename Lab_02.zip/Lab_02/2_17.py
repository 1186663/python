#ZADANIE 2.17
#Posortować wyrazy z napisu line raz alfabetycznie,
#a raz pod względem długości. Wskazówka: funkcja wbudowana sorted().

line = ("Lorem ipsum dolor sit amet, consectetur "
            "adipiscing elit. Proin vulputatevos sed nisl et ultricies. "
            "Nam finibus mauris at massa malesuada, ultricies sollicitudin.")

words = line.split()

# (a) Posortuj alfabetycznie
words_sorted_alphabetically = sorted(words)
# (b) Posortuj według długości
words_sorted_by_length = sorted(words, key=len)

print("a) Wyrazy posortowane alfabetycznie:", words_sorted_alphabetically)
print("b) Wyrazy posortowane według długości:", words_sorted_by_length)
