from points import Point
import unittest


class TestPoint(unittest.TestCase):
    def setUp(self):
        self.p = Point(3, 4)

    def test_create_points(self):
        self.assertEqual(self.p.x, 3)
        self.assertEqual(self.p.y, 4)

    def test_str(self):
        self.assertEqual(self.p.__str__(), "( 3, 4 )")

    def test_repr(self):
        self.assertEqual(self.p.__repr__(), "Point( 3, 4 )")

    def test_eq(self):
        self.assertTrue(self.p.__eq__(self.p))
        self.assertFalse(self.p.__eq__(Point(4, 4)))

    def test_ne(self):
        self.assertFalse(self.p.__ne__(self.p))
        self.assertTrue(self.p.__ne__(Point(4, 4)))

    def test_add(self):
        self.assertEqual(self.p.__add__(Point(-2, 0)), Point(1, 4))

    def test_sub(self):
        self.assertEqual(self.p.__sub__(Point(1, 1)), Point(2, 3))

    def test_mul(self):
        self.assertEqual(self.p.__mul__(Point(1, 1)), self.p)

    def test_cross(self):
        self.assertEqual(self.p.cross(Point(1, 1)), -1)

    def test_length(self):
        self.assertEqual(self.p.length(), 5)

    def test_hash(self):
        self.assertEqual(self.p.__hash__(), 3713083796997400956)


if __name__ == '__main__':
    unittest.main()
