print("Zadanie 4.2")
def make_ruler(n):
    line = "|" + "....|" * n

    numbers = "0"
    for i in range(1, n + 1):
        numbers += str(i).rjust(5)

    return line + "\n" + numbers

def make_grid(rows, cols):
    plusy = "+" + "---+" * rows
    minusy ="|" + "   |" * rows

    wiersz = minusy + "\n" + plusy + "\n"

    return plusy + "\n" + wiersz * cols

print("make_ruler(3): \n" + make_ruler(3))
print("make_grid(3, 4): \n" + make_grid(3, 4))

print("Zadanie 4.3")
def factorial(n):
    suma = n
    if n < 0:
        return "błędna wartość"
    else:
        for i in range(1, n):
            suma *= i
        return suma

print(f"Factorial(4): {factorial(4)} \n")

print("Zadanie 4.4")
def fibonacci(n):
    if n == 1:
        return 1
    elif n <= 0:
        return 0
    else:
        fib_0 = 0
        fib_1 = 1
        for i in range(1, n):
            fib = fib_0 + fib_1
            fib_0 = fib_1
            fib_1 = fib
        return fib

print(f"Fibonacci(9): {fibonacci(9)} \n")

print("Zadanie 4.5")
def odwracanie_iteracyjne(L, left, right):
    if right < left or left < 0 or right > len(L):
        return "błędne dane"
    else:
        for i in range(left, right+1, 1):
            if left < right:
                L[left], L[right] = L[right], L[left]
                left += 1
                right -= 1
        return L

def odwracanie_rekurencyjne(L, left, right):
    if right < left or left < 0 or right > len(L):
        return "błędne dane"
    elif left == right:
        return L
    else:
        L[left], L[right] = L[right], L[left]
        odwracanie_rekurencyjne(L, left+1, right-1)
    return L

L = [1, 2, 3, 4, 5, 6]
print("L: ", L)
print("odwracanie_iteracyjne(L, 1, 5): ", odwracanie_iteracyjne(L, 1, 5))
L = [1, 2, 3, 4, 5, 6]
print("L: ", L)
print("odwracanie_rekuencyjne(L, 2, 4): ", odwracanie_rekurencyjne(L, 2, 4), "\n")

print("Zadanie 4.6")
def sum_seq(sequence):
    sum = 0
    for item in sequence:
        if isinstance(item, (list, tuple)):
            sum += sum_seq(item)
        else:
            sum += item
    return sum

seq = [1, (2, 3), [], [4, (5, 6, 7)], 8, [9]]
print("sum_seq([1, (2, 3), [], [4, (5, 6, 7)], 8, [9]]):", sum_seq(seq), "\n")

print("Zadanie 4.7")
def flatten(sequence):
    flatt = []
    for item in sequence:
        if isinstance(item, (list, tuple)):
            flatt.extend(flatten(item))
        else:
            flatt.append(item)
    return flatt

print("flatten([1, (2, 3), [], [4, (5, 6, 7)], 8, [9]]):", flatten(seq))
