import random


def zero_one():
    while True:
        yield 0
        yield 1


def random_direction():
    directions = ["N", "E", "S", "W"]
    while True:
        yield random.choice(directions)


def days_of_week():
    while True:
        for day in range(7):
            yield day
