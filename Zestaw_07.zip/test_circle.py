import unittest
from circles import Circle
import math


class TestCircle(unittest.TestCase):
    def setUp(self):
        self.circle1 = Circle(0, 0, 1)
        self.circle2 = Circle(1, 1, 1)

    def test_create_circle(self):
        self.assertEqual(self.circle1, Circle(self.circle1.pt.x, self.circle1.pt.y, self.circle1.radius))

    def test_repr(self):
        self.assertEqual(self.circle1.__repr__(), "Circle(0, 0, 1)")

    def test_eq(self):
        self.assertFalse(self.circle1.__eq__(self.circle2))
        self.assertTrue(self.circle1.__eq__(self.circle1))

    def test_ne(self):
        self.assertTrue(self.circle1.__ne__(self.circle2))
        self.assertFalse(self.circle1.__ne__(self.circle1))

    def test_area(self):
        self.assertEqual(self.circle1.area(), math.pi)

    def test_move(self):
        self.circle1.move(-1, 1)
        self.assertEqual(self.circle1.pt.x, -1)
        self.assertEqual(self.circle1.pt.y, 1)

    def test_cover(self):
        self.assertEqual(self.circle1.cover(self.circle2), Circle(0.5, 0.5, (math.sqrt(2) + 1 + 1) / 2))


if __name__ == '__main__':
    unittest.main()