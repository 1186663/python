import pygame
import random
import sys

pygame.init()
WIDTH, HEIGHT = 800, 600
FPS = 60
WHITE, BLACK = (255, 255, 255), (0, 0, 0)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ping Pong")
clock = pygame.time.Clock()


class Paddle(pygame.sprite.Sprite):
    def __init__(self, x, y, player_type):
        super().__init__()
        self.image = pygame.Surface((20, 100))
        self.image.fill(WHITE)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.player_type = player_type

    def update(self):
        keys = pygame.key.get_pressed()
        if self.player_type == "human":
            if keys[pygame.K_w] and self.rect.top > 0:
                self.rect.y -= 5
            if keys[pygame.K_s] and self.rect.bottom < HEIGHT:
                self.rect.y += 5
        elif self.player_type == "player2":
            if keys[pygame.K_UP] and self.rect.top > 0:
                self.rect.y -= 5
            if keys[pygame.K_DOWN] and self.rect.bottom < HEIGHT:
                self.rect.y += 5
        elif self.player_type == "computer":
            if ball.rect.centery < self.rect.centery and self.rect.top > 0:
                self.rect.y -= 5
            elif ball.rect.centery > self.rect.centery and self.rect.bottom < HEIGHT:
                self.rect.y += 5


class Ball(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((20, 20), pygame.SRCALPHA)
        self.image.set_colorkey(BLACK)
        pygame.draw.circle(self.image, WHITE, (20 // 2, 20 // 2), 20 // 2)
        self.rect = self.image.get_rect()
        self.rect.center = (WIDTH // 2, HEIGHT // 2)
        self.speed = [random.choice([-3, 3]), random.choice([-3, 3])]

    def update(self):
        self.rect.x += self.speed[0]
        self.rect.y += self.speed[1]

        if self.rect.top <= 0 or self.rect.bottom >= HEIGHT:
            self.speed[1] = -self.speed[1]
        if pygame.sprite.spritecollide(ball, paddles, False):
            self.speed[0] = -self.speed[0]
        if self.rect.left <= 0:
            self.rect.center = (WIDTH // 2, HEIGHT // 2)
            self.speed = [random.choice([-3, 3]), random.choice([-3, 3])]
            return 2
        elif self.rect.right >= WIDTH:
            self.rect.center = (WIDTH // 2, HEIGHT // 2)
            self.speed = [random.choice([-3, 3]), random.choice([-3, 3])]
            return 1
        return 0


def show_menu():
    fonts = pygame.font.Font(None, 36)
    text1 = fonts.render("1 - Gra z komputerem", True, WHITE)
    text2 = fonts.render("2 - Gra z drugim graczem", True, WHITE)
    screen.blit(text1, (WIDTH // 2 - 150, HEIGHT // 2 - 50))
    screen.blit(text2, (WIDTH // 2 - 150, HEIGHT // 2 + 50))
    pygame.display.flip()


all_sprites = pygame.sprite.Group()
paddles = pygame.sprite.Group()
ball = Ball()
player1 = Paddle(30, HEIGHT // 2, "human")
player2 = Paddle(WIDTH - 30, HEIGHT // 2, "computer")
player1.player_type = "human"
player2.player_type = "computer"
all_sprites.add(player1, player2, ball)
paddles.add(player1, player2)
show_menu()
playing = False
score_player1 = 0
score_player2 = 0

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_1:
                player2.player_type = "computer"
                playing = True
            elif event.key == pygame.K_2:
                player2.player_type = "player2"
                playing = True

    if playing:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        all_sprites.update()

        if ball.update() == 1:
            score_player1 += 1
        elif ball.update() == 2:
            score_player2 += 1

        screen.fill(BLACK)
        all_sprites.draw(screen)
        font = pygame.font.Font(None, 36)
        score_text = font.render(f"{score_player1} - {score_player2}", True, WHITE)
        screen.blit(score_text, (WIDTH // 2 - 50, 20))
        pygame.display.flip()
        clock.tick(FPS)

        if score_player1 == 11 or score_player2 == 11:
            playing = False
            show_menu()
            score_player1 = 0
            score_player2 = 0
    else:
        show_menu()
