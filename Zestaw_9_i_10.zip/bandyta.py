import tkinter as tk
import random


def spin():
    numbers = [random.randint(1, 5) for _ in range(3)]
    label1.config(image=images[numbers[0]])
    label2.config(image=images[numbers[1]])
    label3.config(image=images[numbers[2]])

    if numbers[0] == numbers[1] == numbers[2]:
        result_label.config(text="Wygrana!")
    else:
        result_label.config(text="Spróbuj ponownie.")


root = tk.Tk()
root.title("Jednoręki Bandyta")

images = {}
for i in range(1, 6):
    image = tk.PhotoImage(file=f"{i}.png")
    images[i] = image

frame = tk.Frame(root)
frame.pack()

label1 = tk.Label(frame, image=images[1])
label1.pack(side=tk.LEFT)
label2 = tk.Label(frame, image=images[1])
label2.pack(side=tk.LEFT)
label3 = tk.Label(frame, image=images[1])
label3.pack(side=tk.LEFT)

spin_button = tk.Button(root, text="Losuj", command=spin)
spin_button.pack()

result_label = tk.Label(root, text="", font=("Helvetica", 24))
result_label.pack()

root.mainloop()
