#ZADANIE 3.8
#Dla dwóch sekwencji liczb lub znaków znaleźć:
# (a) listę elementów występujących jednocześnie w obu sekwencjach (bez powtórzeń),
# (b) listę wszystkich elementów z obu sekwencji (bez powtórzeń).

# Dwie sekwencje (listy) przykładowych elementów
seq1 = [1, 2, 3, 4, 5]
seq2 = [3, 4, 5, 6, 7]

# (a) Lista elementów występujących jednocześnie w obu sekwencjach (bez powtórzeń)
common_el = list(set(seq1).intersection(seq2))

# (b) Lista wszystkich elementów z obu sekwencji (bez powtórzeń)
all_el = list(set(seq1).union(seq2))

print("(a) Elementy występujące w obu sekwencjach:", common_el)
print("(b) Wszystkie elementy z obu sekwencji:", all_el)
