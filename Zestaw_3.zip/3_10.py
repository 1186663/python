#ZADANIE 3.10
#Stworzyć słownik tłumaczący liczby zapisane w systemie rzymskim
# (z literami I, V, X, L, C, D, M) na liczby arabskie (podać kilka
# sposobów tworzenia takiego słownika). Mile widziany kod tłumaczący
# całą liczbę [funkcja roman2int()].

def roman2int(roman, dictionary):
    result = 0
    prev_value = 0

    for char in reversed(roman):
        value = dictionary[char]
        if value < prev_value:
            result -= value
        else:
            result += value
        prev_value = value

    return result


#tuple
roman_dict = [('I', 1), ('V', 5), ('X', 10), ('L', 50), ('C', 100), ('D', 500), ('M', 1000)]
roman_dict_tuple = dict(roman_dict)
print(roman2int("XIV", roman_dict_tuple))

#zip
roman_dict_zip = dict(zip("IVXLCDM", [1, 5, 10, 50, 100, 500, 1000]))
print(roman2int("XIV", roman_dict_zip))

#bezposrednie definiowanie
roman_dict = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
print(roman2int("XIV", roman_dict))