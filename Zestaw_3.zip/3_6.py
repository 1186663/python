#ZADANIE 3.6
#Napisać program rysujący prostokąt zbudowany z małych kratek.
# Należy zbudować pełny string, a potem go wypisać. Przykładowy
# prostokąt składający się 2x4 pól ma postać:

#+---+---+---+---+
#|   |   |   |   |
#+---+---+---+---+
#|   |   |   |   |
#+---+---+---+---+

x = int(input("Podaj szerokosc x: "))
y = int(input("Podaj wysokosc y: "))

plusy = "+" + "---+" * x
minusy ="|" + "   |" * x

wiersz = minusy + "\n" + plusy + "\n"

print(plusy)
print(wiersz * y)

