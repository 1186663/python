# ZADANIE 3.4
# Napisać program pobierający w pętli od użytkownika liczbę rzeczywistą x
# (typ float) i wypisujący x oraz trzecią potęgę x. Zatrzymanie programu
# następuje po wpisaniu z klawiatury stop. Jeżeli użytkownik wpisze napis
# zamiast liczby, to program ma wypisać komunikat o błędzie i kontynuować pracę.

while True:
    x = input("Wprowadź liczbę rzeczywistą (wpisz 'stop' aby zakończyć): ")

    if x == 'stop':
        break

    x = float(x)

    try:
        print(f"{x}^3 = {x ** 3}")
    except ValueError:
        print("Wprowadzono bledne dane. Podaj liczbe rzeczywista")
