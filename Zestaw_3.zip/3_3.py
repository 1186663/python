#ZADANIE 3.3
#Wypisać w pętli liczby od 0 do 30 z wyjątkiem liczb podzielnych przez 3.

for i in range(0, 30):
    if i % 3 != 0:
        print(i)