import pytest
from rectangles import Rectangle
from points import Point


def test_from_points():
    rectangle = Rectangle.from_points([(1, 2), (3, 4)])
    assert rectangle == Rectangle(1, 2, 3, 4)


def test_properties():
    rectangle = Rectangle(1, 2, 5, 6)
    assert rectangle.top == 6
    assert rectangle.left == 1
    assert rectangle.bottom == 2
    assert rectangle.right == 5
    assert rectangle.width == 4
    assert rectangle.height == 4
    assert rectangle.top_left == Point(1, 6)
    assert rectangle.bottom_left == Point(1, 2)
    assert rectangle.top_right == Point(5, 6)
    assert rectangle.bottom_right == Point(5, 2)

    assert rectangle.center == Point(3, 4)


def test_center():
    rectangle = Rectangle(1, 2, 5, 6)
    assert rectangle.center == Point(3, 4)


def test_str():
    rectangle = Rectangle(1, 1, 3, 3)
    assert rectangle.__str__() == "[(1, 1), (3, 3)]"


def test_repr():
    rectangle = Rectangle(1, 1, 3, 3)
    assert rectangle.__repr__() == "Rectangle(1, 1, 3, 3)"


def test_eq():
    rectangle1 = Rectangle(1, 1, 3, 3)
    assert rectangle1.__eq__(rectangle1)


def test_ne():
    rectangle1 = Rectangle(1, 1, 3, 3)
    rectangle2 = Rectangle(2, 1, 4, 3)
    assert rectangle1.__ne__(rectangle2)


def test_area():
    rectangle = Rectangle(1, 1, 3, 3)
    assert rectangle.area() == 4


def test_move():
    rectangle = Rectangle(1, 1, 3, 3)
    rectangle.move(1, 1)
    assert rectangle.top == 4
    assert rectangle.bottom == 2
    assert rectangle.left == 2
    assert rectangle.right == 4


if __name__ == '__main__':
    pytest.main()
